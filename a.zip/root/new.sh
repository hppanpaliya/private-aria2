docker run --restart=always -d -v /var/www/html/aria2:/data -p 6800:6800 -p 9100:8080 --name="webui-aria2" fjudith/webui-aria2

